public class NetFlix{
    public static void main(String[] args){
    	MainMenu netflix = new MainMenu();
    }
}